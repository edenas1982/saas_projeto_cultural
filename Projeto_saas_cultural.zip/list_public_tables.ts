// Arquivo temporario limpo.
